require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "com.androlua.*"
import "java.io.*"
import "android.text.method.*"
import "android.content.*"
import "java.util.*"
import "java.lang.*"
import "android.*"
import "layout"
import "android.widget.AdapterView"
import "android.database.sqlite.SQLiteDatabase"
import "android.widget.ArrayAdapter"
import "android.widget.ArrayListAdapter"

activity.setContentView(loadlayout(layout))


function successed(msg)
  local open_dlg = AlertDialogBuilder(activity)
  open_dlg.setTitle("提示！")
  open_dlg.Message = msg
  open_dlg.setPositiveButton("确定", nil)
  open_dlg.setNeutralButton("取消",nil)
  open_dlg.show()
end

--格式化路径
function formatPath(s)
  local p = s
  if p:sub(#p,#p) == "/" then
    return p
   else
    return p.."/"
  end
end

--设置路径
function setPath(p1,p2,temp)
  luadir = p1
  dbpath.Text = p1..p2
  if temp then
    local temp2 = tostring(dbpath.getText())
    local open_dlg = AlertDialogBuilder(activity)
    open_dlg.setTitle("提示！")
    open_dlg.Message = "确定要删除  "..temp2.."  ?"
    open_dlg.setPositiveButton("确定", {
      onClick = function()
        if pcall(deleteFile,temp2) then
          dbpath.Text = temp
          if temp==temp2 then
            dbpath.Text = ""
          end
          successed("删除成功")
         else
          successed("删除失败")
          dbpath.Text = ""
        end
      end
    })
    open_dlg.setNeutralButton("取消",{
      onClick = function()
        dbpath.Text = ""
      end
    })
    open_dlg.show()
   else
     local dbs = tostring(dbpath.getText())
     if dbs=="" or dbs == nil or dbs=="nil" or dbs=="" then
     print("文件无效")
     else
      activity.newActivity("sql/main.lua",Object{tostring(dbpath.getText())})
     end
  end
end

--打开文件路径
function open(p,temp)
  if p == luadir then
    return nil
  end
  if File(open_title.getText()).isFile() then
    luadir = File(open_title.getText()).getParentFile().getAbsolutePath()
    luadir = formatPath(luadir)
    list(listview,luadir,temp)
   elseif p:find("%.%./") then
    luadir = luadir:match("(.-)[^/]+/$")
    if luadir == "/" then
      luadir = "/sdcard/"
      successed("到顶了")
    end
    list(listview, luadir,temp)
   elseif p:find("/") then
    luadir = luadir .. p
    list(listview, luadir,temp)
   else
    setPath(luadir,p,temp)
    open_dlg.hide()
    open_dlg = nil
  end
end

--排序
function sort(a, b)
  if string.lower(a) < string.lower(b) then
    return true
   else
    return false
  end
end

--列表
function list(v, p,temp)
  import "java.io.File"
  local f = File(p)
  if not f then
    open_title.setText(p)
    local adapter = ArrayAdapter(activity, android.R.layout.simple_list_item_1, String {})
    v.setAdapter(adapter)
    return
  end

  local fs = f.listFiles()
  fs = fs or String[0]
  Arrays.sort(fs)
  local t = {}
  local td = {}
  local tf = {}
  if p ~= "/" then
    table.insert(td, "../")
  end
  for n = 0, #fs - 1 do
    local name = fs[n].getName()
    if fs[n].isDirectory() then
      table.insert(td, name .. "/")
     elseif name:find("%.db$") or name:find("%.sql$") or name:find("%.flnb$") then
      table.insert(tf, name)
    end
  end
  table.sort(td, sort)
  table.sort(tf, sort)
  for k, v in ipairs(tf) do
    table.insert(td, v)
  end
  open_title.setText(p)
  open_dlg.setItems(td)
end

--路径选择弹窗
function create_open_dlg(temp)
  if open_dlg then
    return
  end
  open_dlg = AlertDialogBuilder(activity)
  open_dlg.setTitle("浏览")
  open_title = TextView(activity)
  listview = open_dlg.ListView
  listview.FastScrollEnabled = true
  listview.addHeaderView(open_title)
  listview.setOnItemClickListener(AdapterView.OnItemClickListener {
    onItemClick = function(parent, v, pos, id)
      open(v.Text,temp)
    end
  })
end

luadir = "/sdcard/"

opendb.onClick = function()
  local temp = tostring(dbpath.getText())
  if choice.isChecked() and temp and temp~="nil" and temp~="" then
    activity.newActivity("sql/main.lua",Object{temp})
   else
    open_dlg = nil
    create_open_dlg()
    list(listview, luadir)
    open_dlg.show()
  end
end

createdb.onClick = function()
  local open_dlg = AlertDialogBuilder(activity)
  open_dlg.setTitle("输入路径")
  local edit=EditText(activity)
  open_dlg.setView(edit)
  open_dlg.setPositiveButton("确定", {
    onClick=function()
      local str = tostring(edit.getText())
      if File(str).getParentFile().exists() then
        if String(str).endsWith(".db") then
          db = SQLiteDatabase.openOrCreateDatabase( str,nil, nil);
          dbpath.Text = str
          path = str
          if db then
            db.close()
          end
          successed("创建成功")
         else
          successed("请以.db或.sql为文件后缀")
        end
       else
        successed("父路径不存在")
      end
    end
  })
  open_dlg.setNeutralButton("取消",nil)
  open_dlg.show()
end

function deleteFile(f)
  File( f).delete()
end

deletedb.onClick = function()
  local temp = tostring(dbpath.getText())
  open_dlg = nil
  create_open_dlg(temp)
  list(listview, luadir,temp)
  open_dlg.show()
end