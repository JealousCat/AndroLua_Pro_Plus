require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "java.io.File"
import "java.lang.String"
import "android.database.sqlite.SQLiteDatabase"
import "android.content.Context"
import "android.view.View$OnLongClickListener"
activity.setContentView(loadlayout("layout"))

function successed(msg)
  local open_dlg = AlertDialogBuilder(activity)
  open_dlg.setTitle("提示！")
  open_dlg.Message = msg
  open_dlg.setPositiveButton("确定", nil)
  open_dlg.show()
end

function copyText(txt)
  activity.getSystemService(Context.CLIPBOARD_SERVICE).setText(txt)
  print("复制成功")
end

local path = tostring(activity.getArg(0))

function exec( sql )
  if db ~= nil then
    return db.execSQL( sql )
  end
end

function raw( sql )
  if db ~= nil then
    return db.rawQuery( sql,nil )
  end
end

function openDB()
  if path ~= nil then
    return SQLiteDatabase.openOrCreateDatabase( path,nil, nil);
   else
    return nil
  end
end

if path and tostring(path)~="nil" then
  dbpath.Text = tostring(path)
end

function tabletostring(_table)
  if _table == nil then return "nil" end
  if tostring(_table) == "LuaTable" or type(_table) ~= "table" then
    _table = luajava.astable(_table)
  end
  local s = "{"
  for k, v in pairs(_table) do
    if type(k) == "string" then
      s = s.."['"..k.."'] = "
     else
      s = s.."["..tostring(k).."] = "
    end
    if type(v) == "string" then
      s = s.."'"..v.."', "
     elseif type(v) == "table" then
      s = s..tabletostring(v)..","
     elseif tostring(v) == "LuaTable" then
      s = s..tabletostring(v)..","
     else
      s = s..tostring(v)..","
    end
  end
  s = s.."}"
  return s
end

local function adds()
  local path = tostring(activity.getArg(0))
  if path then
    require "import"
    import "java.lang.String"
    import "android.database.sqlite.SQLiteDatabase"
    local _db = SQLiteDatabase.openOrCreateDatabase( path,nil, nil);
    local sql = "pragma table_info([" .. tostring(activity.getArg(1)) .. "])";
    local res = _db.rawQuery(sql, nil);
    local cols = res.getCount();
    local fields = {[1]={"id", "name", "type", "notnull", "dflt_value", "pk"}}
    local columns = res.getColumnCount();
    local i = 0;
    while (res.moveToNext()) do
      local a = {}
      for j = 0,columns-1 do
        a[j+1]=res.getString(j);
      end
      fields[i+2] = a
      i=i+1;
    end
    res.close();
    _db.close()
    _db = nil
    return fields
  end
  return fields
end


local function names()
  local path = tostring(activity.getArg(0))
  if path then
    require "import"
    import "java.lang.String"
    import "android.database.sqlite.SQLiteDatabase"
    local _db = SQLiteDatabase.openOrCreateDatabase( path,nil, nil);
    local sql = "pragma table_info([" .. tostring(activity.getArg(1)) .. "])";
    local res = _db.rawQuery(sql, nil);
    local cols = res.getCount();
    local fields = {}
    local types = {}
    local columns = res.getColumnCount();
    local i = 0;
    while (res.moveToNext()) do
      fields[i+1] = res.getString(1);
      types[i+1] = res.getString(2);
      i=i+1;
    end
    res.close();
    _db.close()
    _db = nil
    return fields,types
  end
  return fields,types
end

function getMaxN(t)
  local x = nil
  for k,v in pairs(t) do
    if type(k)=="number" then
      if x == nil or k >= x then
        x = k
      end
    end
  end
  return (x or 0)
end

function sp2dp()
  local ms = activity.getResources().getDisplayMetrics()
  local fsc = tonumber(ms.scaledDensity)
  local sc = tonumber(ms.density)
  local sp = tonumber(yj.getTextSize()/#tostring(yj.getText()))
  return math.tointeger(sp*fsc)
end

function adapter(t)
  item = nil
  package.loaded["item"]=nil
  if not t or #t <= 0 then
    return ArrayAdapter(activity, android.R.layout.simple_list_item_1, String {})
  end
  local backcolor = {0x251e8ae8,0xff1e10e8}
  local textcolor = {0xff000000,0xffffffff}
  local data={}
  local len = getMaxN(t[1])

  local strlen = {}
  local size = sp2dp()


  for j=1,len do
    local sl = 0
    for n=1,#t do
      local str = t[n][j] and (#t[n][j] > 100 and t[n][j]:sub(1,100).."...<文本太大，隐藏了后续内容>" or t[n][j]) or ""
      t[n][j] = str
      if not sl or #str >= sl then
        sl = #str
      end
    end
    strlen[j] = sl*size + 10
  end

  import "item"

  table.insert(item,{
    TextView;
    layout_gravity="center";
    text="编辑";
    layout_height="fill";
    id="editT";
  })

  for n=1,len do
    table.insert(item,{
      TextView;
      layout_height="fill";
      id="I_d"..n;
      layout_width=strlen[n].."dp"
    })
  end

  local adp=LuaAdapter(activity,data,item)
  --添加数据
  local headertext = {0xff000000,0xffffffff}
  local headerback = {0x2e1ecb1f,0xff1e6124}

  local p = {}

  for j=1,len do
    p["I_d"..j]={
      Text=t[1][j] or "",
      textColor=headertext[j%2+1],
      backgroundColor=headerback[j%2+1],
    }
  end

  table.insert(data,p)

  for n=2,#t do
    local p = {}
    for j=1,len do
      p["I_d"..j]={
        Text = t[n][j],
        textColor=textcolor[j%2+1],
        backgroundColor=backcolor[j%2+1],
      }
    end
    table.insert(data,p)
  end
  return adp
end

function loadTables()
  local t = adds()
  if t ~= nil and #t > 0 then
    vlist.Adapter=adapter(t)
  end
end

function loadtable()
  call("loadTables")
end

thread(loadtable)

function editItem( idx,len)
  import "com.androlua.LuaEditor"
  local fields = rawItem(idx,len)
  local a,b = names()
  local dl ={
    LinearLayout,
    layout_width="fill",
    layout_height="fill",
    orientation="vertical";
    {
      LinearLayout;
      layout_height="50dp";
      layout_marginTop="10dp";
      orientation="horizontal";
      layout_width="fill";
      gravity="center";
      {
        Button;
        layout_height="45dp";
        layout_gravity="center";
        text="新增";
        id="createsql";
      };
      {
        Button;
        layout_height="45dp";
        layout_gravity="center";
        text="删除";
        id="deletesql";
      };
      {
        Button;
        layout_height="45dp";
        layout_gravity="center";
        text="更新";
        id="updatesql";
      };
    };
  }
  local l = tointeger((1/(#a+1))*100)
  for n=1,#a do
    table.insert(dl,
    {
      LinearLayout;
      layout_height="50dp";
      layout_marginTop="10dp";
      orientation="horizontal";
      layout_width="fill";
      gravity="center";
      {
        TextView,
        text= a[n],
        layout_width="50%w",
        layout_height="20dp",
        layout_marginLeft="4dp";
      },
      {
        TextView,
        text= "导出文本",
        layout_width="fill",
        id = "Import"..n,
        layout_height="20dp",
        layout_marginLeft="4dp";
      }})
    local xx = ((#fields[n]/50)*(1.0/40.0))*100*8
    if xx >= l then
      xx = l*1.5
    end
    table.insert(dl,{
      LuaEditor,
      layout_width="fill",
      layout_height=xx.."%h",
      id="A"..a[n];
    })
  end

  local lb = AlertDialog.Builder(activity)
  lb.setView(loadlayout(dl)).setNeutralButton("取消",nil)
  lb=lb.create()

  if not db then
    db = SQLiteDatabase.openOrCreateDatabase(path,nil, nil);
  end

  createsql.onClick=function()
    if db then
      local vlua = {}
      for n=1,#a do
        local str = tostring(_ENV["A"..a[n]].getText())
        if checktype(b[n])=="text" then
          table.insert(vlua,"'"..str.."'")
         else
          table.insert(vlua,str)
        end
      end
      vlua = table.concat(vlua,",")
      if pcall(exec,"insert into "..tostring(activity.getArg(1)).."("..table.concat(a,",")..") values("..vlua..")") then
        thread(AllData)
        successed("插入成功")
       else
        successed("插入失败，可能已存在对应值")
      end
      if db then
        db.close()
        db = nil
      end
     else
      successed("环境数据丢失，请重新打开数据文件")
      dn=nil
    end
    lb.create().dismiss()
  end

  updatesql.onClick = function()
    if db then
      local vlua = {}
      local vv = {}

      for n=1,#a do
        local str = tostring(_ENV["A"..a[n]].getText())
        if checktype(b[n])=="text" then
          table.insert(vlua,a[n].."='"..str.."'")
         else
          table.insert(vlua,a[n].."="..str)
        end
      end
      for n=2,#vlua do
        table.insert(vv,vlua[n])
      end

      if pcall(exec,"update "..tostring(activity.getArg(1)).." set "..table.concat(vv,",").." where "..vlua[1]) then
        thread(AllData)
        successed("更新成功")
       else
        successed("更新失败")
      end
      if db then
        db.close()
        db = nil
      end
     else
      successed("环境数据丢失，请重新打开数据文件")
      db=nil
    end
    lb.create().dismiss()
  end

  deletesql.onClick = function()
    if db then
      local vlua = {}

      for n=1,#a do
        local str = tostring(_ENV["A"..a[n]].getText())
        if checktype(b[n])=="text" then
          table.insert(vlua,a[n].."='"..str.."'")
         else
          table.insert(vlua,a[n].."="..str)
        end
      end

      if pcall(exec,"delete from "..tostring(activity.getArg(1)).." where " ..table.concat(vlua," and ")) then
        thread(AllData)
        successed("删除成功")
       else
        successed("删除失败")
      end
      if db then
        db.close()
        db = nil
      end
     else
      successed("环境数据丢失，请重新打开数据文件")
      db=nil
    end
    lb.create().dismiss()
  end
  lb.show()
  for n=1,#a do
    if _ENV["A"..a[n]] then
      _ENV["A"..a[n]].setWordWrap(true)
      _ENV["A"..a[n]].setText(fields[n])
      _ENV["A"..a[n]].setAutoComplete(false)
      _ENV["A"..a[n]].setAutoIndent(false)
      _ENV["A"..a[n]].setShowLineNumbers(false)
      _ENV["Import"..n].onClick = function()
        local fp= io.open(path.."."..tostring(activity.getArg(1)).."."..a[1].."."..a[n]..".json","w+")
        fp:write(fields[n])
        fp:close()
        local open_dlg = AlertDialogBuilder(activity)
        open_dlg.setTitle("提示！")
        open_dlg.Message = "导出成功！\n文件路径:\n"..path.."."..tostring(activity.getArg(1)).."."..a[1].."."..a[n]..".json";
        open_dlg.setPositiveButton("确定", nil)
        open_dlg.show()
      end
    end
  end
end


function rawItem(idx,len)
  if not db then
    db = SQLiteDatabase.openOrCreateDatabase(path,nil, nil);
  end
  local sql = "select * from "..tostring(activity.getArg(1))
  local _,res = pcall(raw,sql)
  if _ then
    local cols = res.getCount();
    local fields = {}
    local columns = res.getColumnCount();
    local i = 0;
    while (res.moveToNext()) do
      if len==i then
        local a = {}
        for j = 0,columns-1 do
          a[j+1]=res.getString(j);
        end
        fields = a
      end
      i=i+1;
    end
    res.close();
    db.close()
    db = nil
    return fields
   else
    successed("查询失败")
    db.close()
    db=nil
  end
  return nil
end

function updateTable(t)
  local ad = vlist.getAdapter()
  if ad then
    ad.clear()
    ad.setNotifyOnChange(true)
  end
  package.loaded["item"]=nil
  vlist.Adapter=adapter(t)
  vlist.onItemClick=function(aa,vv,pp,ii)
    if ii~=1 then
      local textView=vv.getChildAt(1).getText()
      editItem(textView,ii-2)
    end
  end
end

function updateAll()
  updateTable(adds())
end

function AllTables()
  call("updateAll")
end

idx.onClick = function()
  thread(AllTables)
end

function checktype(txt)
  local ty = tostring(txt):lower()
  if ty=="int" or
    ty=="integer" or
    ty=="tinyint" or
    ty=="smallint" or
    ty=="mediumint" or
    ty=="bigint" or
    ty=="unsigned big int" or
    ty=="int2" or
    ty=="int8" then
    return "number"
   elseif ty=="character" or
    ty=="character(20)" or
    ty=="varchar(255)" or
    ty=="varying character(255)" or
    ty=="nchar(55)" or
    ty=="native character(70)" or
    ty=="nvarchar(100)" or
    ty=="text" or
    ty=="clob" then
    return "text"
   elseif ty=="real" or
    ty=="double" or
    ty=="double precision" or
    ty=="float" then
    return "number"
   else
    return "text"
  end
end

create.onClick = function()
  local a,b = names()
  local dl ={
    LinearLayout,
    layout_width="fill",
    layout_height="fill",
    orientation="vertical";
  }

  for n=1,#a do
    table.insert(dl,{
      TextView,
      text= a[n],
      layout_width="fill",
      layout_height="20dp",
      layout_marginLeft="4dp";
    })

    table.insert(dl,{
      LuaEditor,
      layout_width="fill",
      layout_height="50dp",
      id="A"..a[n];
    })
  end

  if not db then
    db = SQLiteDatabase.openOrCreateDatabase(path,nil, nil);
  end

  AlertDialog.Builder(activity)
  .setView(loadlayout(dl))
  .setPositiveButton("确定", {
    onClick=function()
      if db then
        local vlua = {}
        for n=1,#a do
          local str = tostring(_ENV["A"..a[n]].getText())
          if checktype(b[n])=="text" then
            table.insert(vlua,"'"..str.."'")
           else
            table.insert(vlua,str)
          end
        end
        vlua = table.concat(vlua,",")
        if pcall(exec,"insert into "..tostring(activity.getArg(1)).."("..table.concat(a,",")..") values("..vlua..")") then
          thread(AllData)
          successed("插入成功")
         else
          successed("插入失败，可能已存在对应值")
        end
        db.close()
        db = nil
       else
        successed("环境数据丢失，请重新打开数据文件")
      end
    end})
  .setNeutralButton("取消",{
    onClick=function()
      if db then
        db.close()
        db=nil
      end
    end
  })
  .show()

end

local function Storage()
  if not db then
    db = SQLiteDatabase.openOrCreateDatabase(path,nil, nil);
  end
  local sql = "select * from "..tostring(activity.getArg(1))
  local _,res = pcall(raw,sql)
  if _ then
    local cols = res.getCount();
    local fields = {names()}
    local columns = res.getColumnCount();
    local i = 0;
    while (res.moveToNext()) do
      local a = {}
      for j = 0,columns-1 do
        a[j+1]=res.getString(j);
      end
      fields[i+2] = a
      i=i+1;
    end
    res.close();
    db.close()
    db = nil
    return fields
   else
    successed("查询失败")
  end
  if db then
    db.close()
    db=nil
  end
  return nil
end

function updateAlldata()
  updateTable(Storage())
end


function AllData()
  call("updateAlldata")
end

update.onClick = function()
  thread(AllData)
end
