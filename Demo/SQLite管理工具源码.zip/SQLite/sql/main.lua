require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "com.androlua.*"
import "java.io.*"
import "android.text.method.*"
import "android.content.*"
import "java.util.*"
import "java.lang.*"
import "android.*"
import "layout"
import "android.widget.AdapterView"
import "android.database.sqlite.SQLiteDatabase"
import "android.widget.ArrayAdapter"
import "android.widget.ArrayListAdapter"

activity.setContentView(loadlayout(layout))

function successed(msg)
  local open_dlg = AlertDialogBuilder(activity)
  open_dlg.setTitle("提示！")
  open_dlg.Message = msg
  open_dlg.setPositiveButton("确定", nil)
  open_dlg.setNeutralButton("取消",nil)
  open_dlg.show()
end

function exec( sql )
  if db ~= nil then
    return db.execSQL( sql )
  end
end

function raw( sql )
  if db ~= nil then
    return db.rawQuery( sql,nil )
  end
end

function openDB()
  if luadir ~= nil then
    return SQLiteDatabase.openOrCreateDatabase(luadir,nil, nil);
   else
    return nil
  end
end

import "item"

function adapter(t,tgggbackground,CBLACK)
  if not t or #t <= 0 then
    return ArrayAdapter(activity, android.R.layout.simple_list_item_1, String {})
  end
  local data={}
  local adp=LuaAdapter(activity,data,item)
  --添加数据
  for n=1,#t do
    table.insert(data,{
      card={
        BackgroundColor=tgggbackground,
      },
      text={
        Text=t[n],
        textColor=CBLACK,
      },
    })
  end
  return adp
end

function DBtables(dir)
  local sql="select name from sqlite_master where type = 'table' order by name"
  if db ~= nil then
    db.close()
    db = nil
  end
  vlist.FastScrollEnabled = true
  db = openDB()
  if db then
    local r=raw(sql)
    local tables = {"sqlite_master"}
    while r.moveToNext() do
      local name = r.getString(0)
      table.insert(tables,name)
    end
    r.close()
    db.close()
    db = nil
    vlist.Adapter=adapter(tables,0x2f568ab1,0xffffffff)
    vlist.onItemClick=function(aa,vv,pp,ii)
      if not open_dlg then
        local textView=vv.getChildAt(0).getChildAt(0).getChildAt(1)
        local s=tostring(textView.Text)
        print(s,ii)
        activity.newActivity("View/main.lua",Object{luadir,s,'table'})
      end
    end
    vlist.onItemLongClick = function(aa,vv,pp,ii)
      local textView=vv.getChildAt(0).getChildAt(0).getChildAt(1)

      local s=tostring(textView.Text)
      open_dlg = AlertDialogBuilder(activity)
      open_dlg.setTitle("提示！")
      open_dlg.Message = "确定删除"..s.."  ?"
      open_dlg.setPositiveButton("确定", {
        onClick=function()
          db = openDB()
          if pcall(exec,"drop table "..s) then
            db.close()
            db=nil
            DBtables(luadir)
            successed("删除成功")
            open_dlg = nil
           else
            db.close()
            db = nil
            successed("删除失败")
            open_dlg = nil
          end
        end
      })
      open_dlg.setNeutralButton("取消",{
        onClick=function()
          open_dlg = nil
        end
      })
      open_dlg.show()
    end
  end
end

function DBviews(dir)
  local sql = "select name from sqlite_master where type = 'view'"
  if db ~= nil then
    db.close()
    db = nil
  end
  vlist.FastScrollEnabled = true
  db = openDB()
  if db then
    local r=raw(sql)
    local tablex = {}
    while r.moveToNext() do
      local name = r.getString(0)
      table.insert(tablex,name)
    end
    r.close()
    if db then
      db.close()
      db = nil
    end
    Toast.makeText(activity,"打开完毕",10).show()
    vlist.Adapter=adapter(tablex,0x2f568ab1,0xffffffff)
    vlist.onItemClick=function(aa,vv,pp,ii)
      local textView=vv.getChildAt(0).getChildAt(0).getChildAt(1)
      local s=tostring(textView.Text)
      print(s,ii)
      -- activity.newActivity("View/main.lua",Object{luadir,s,'view'})
    end
  end
end

function DBindexs(dir)
  local sql = "select name from sqlite_master where type = 'index'"
  if db ~= nil then
    db.close()
    db = nil
  end
  vlist.FastScrollEnabled = true
  db = openDB()
  if db then
    local r=raw(sql)
    local tablex = {}
    while r.moveToNext() do
      local name = r.getString(0)
      table.insert(tablex,name)
    end
    r.close()
    if db then
      db.close()
      db = nil
    end
    Toast.makeText(activity,"打开完毕",0).show()
    vlist.Adapter=adapter(tablex,0x2f568ab1,0xffffffff)
    vlist.onItemClick=function(aa,vv,pp,ii)
      local textView=vv.getChildAt(0).getChildAt(0).getChildAt(1)
      local s=tostring(textView.Text)
      print(s,ii)
      --activity.newActivity("View/main.lua",Object{luadir,s,'index'})
    end
  end
end

tables.onClick = function()
  local f = File(dbpath.getText())
  if f and f.exists() then
    DBtables(luadir)
   else
    successed("无内容")
  end
end

views.onClick = function()
  local f = File(dbpath.getText())
  if f and f.exists() then
    DBviews(luadir)
   else
    successed("无内容")
  end
end

indexs.onClick = function()
  local f = File(dbpath.getText())
  if f and f.exists() then
    DBindexs(luadir)
   else
    successed("无内容")
  end
end

function onCreate(xx)
  luadir=tostring(activity.getArg(0))
  dbpath.Text=luadir
  DBtables(luadir)
end

newtables.onClick = function()
  db = openDB()
  if db then
    local ly ={
      LinearLayout;
      layout_height="fill";
      orientation="vertical";
      layout_width="fill";
      {
        LuaEditor,
        layout_width="fill",
        layout_height="50%h",
        text=[[
    --将可以采用如下的固定格式进行字段的创建
    --1,2,3...n表示字段在数据库中的先后顺序
    --return {
    --["表名"]={
    --  [1]={"字段名1","字段类型1"},
    --  [3]={"字段名3","字段类型3"},
    --  [2]={"字段名2","字段类型2"},
    --  更多内容
    --  },
    --}
    
    --当你确定按顺序排时，1,2,3……省略不写
    --return {
    --["表名"]={
    --  {"字段名1","字段类型1"},
    --  {"字段名2","字段类型2"},
    --  {"字段名3","字段类型3"},
    --  更多内容
    --  },
    --}
    
    --下面开始创建你的内容
    return {
      ["your_table_name"]={
      --写入内容
    }
  }
    ]],
        id="A";
      };
    }
    local open_dlg = AlertDialogBuilder(activity)
    open_dlg.setTitle("输入字段名和类型")
    open_dlg.setView(loadlayout(ly))
    A.format()
    open_dlg.setPositiveButton("确定", {
      onClick=function()
        local t = load(tostring(A.getText()))()
        for k,v in pairs(t) do
          if type(k)=="string" and type(v)=="table" then
            local s = {}
            local flags = true
            for kk,vv in ipairs(v) do
              if #vv ~= 2 then
                flags = false
               else
                table.insert(s,table.concat(vv," "))
              end
            end
            if flags then
              local sql="create table "..k.."("..table.concat(s,",")..")"
              print(sql)
              if pcall(exec,sql) then
                successed("创建成功")
                DBindexs(luadir)
               else
                successed("创建失败")
              end
              if db then
                db.close()
                db=nil
              end
             else
              successed("一个字段只能有一个数据类型，请检查你的内容")
            end
          end
        end
      end
    })
    open_dlg.setNeutralButton("取消",nil)
    open_dlg.show()
  end
  if db then
    db.close()
    db=nil
  end
end